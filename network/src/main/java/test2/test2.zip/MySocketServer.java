package test2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class MySocketServer extends Thread {
	static ArrayList<Socket> list = new ArrayList<Socket>(); 
	static Socket socket = null;
	
	public MySocketServer(Socket socket) {
		this.socket = socket;
		list.add(socket);
	}
	
    public void run() {
		try {
			System.out.println(socket.getInetAddress() );
		
			InputStream input = socket.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(input));
	
			OutputStream out = socket.getOutputStream();
			PrintWriter writer = new PrintWriter(out, true);

			
			String readValue;
			String name = null; 
			boolean identify = false;
			
			while((readValue = reader.readLine()) != null ) { 
				if(!identify) {
					name = readValue;
					identify = true;
					writer.println(name);
					continue;
				}
				
				for(int i = 0; i<list.size(); i++) {
					out = list.get(i).getOutputStream();
					writer = new PrintWriter(out, true);	
					writer.println(name + " : " + readValue); 
				}
			}
		} catch (Exception e) {
		    e.printStackTrace(); 
		}    		
    }	
	
	public static void main(String[] args) {
		try {
			int socketPort = 60000; 
			ServerSocket serverSocket = new ServerSocket(socketPort); 
			System.out.println("socket : " + socketPort);
			
            while(true) {
                Socket socketUser = serverSocket.accept();
                Thread thd = new MySocketServer(socketUser); 
                thd.start();
            }                 
            
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
