package test2;

import java.io.IOException;
import java.net.Socket;

public class MySocketClient {
	
	public static void main(String[] args) {
		try {
			Socket socket = null;
			socket = new Socket("127.0.0.1", 60000); 
			System.out.println("connected");
			
			ListeningThread t1 = new ListeningThread(socket);
			WritingThread t2 = new WritingThread(socket);

			t1.start(); // ListeningThread Start
			t2.start(); // WritingThread Start
            
		} catch (IOException e) {
			e.printStackTrace(); 
		}
	}
}

