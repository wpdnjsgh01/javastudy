package Multitest;

import java.io.*;
import java.net.*;
import java.util.*;

// 소켓통신용 서버 코드
public class MySocketServer extends Thread {

	static ArrayList<Socket> list = new ArrayList<Socket>();

	static Socket socket = null;

	public MySocketServer(Socket socket) {
		this.socket = socket;
		list.add(socket);
	}

	public void run() {
		try {
			System.out.println("CONNECTED TO " + socket.getInetAddress());

			//InputStream input = socket.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
			
			//OutputStream out = socket.getOutputStream();
			PrintWriter writer = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);

			writer.println("> SET ID");

			String readValue; // Client에서 보낸 값 저장
			String name = null; // 클라이언트 이름 설정용
			boolean identify = false;

			while ((readValue = reader.readLine()) != null) {
				if (!identify) { // 연결 후 한번만 노출
					name = readValue; // 이름 할당
					identify = true;
					writer.println(name + "님이 접속하셨습니다.");
					continue;
				}

				for (int i = 0; i < list.size(); i++) {
					//out = list.get(i).getOutputStream();
					//writer = new PrintWriter(out, true);
					writer.println(name + " : " + readValue);
				}
			}
		} catch (Exception e) {
			e.printStackTrace(); // 예외처리
		}
	}

	public static void main(String[] args) {
		try {
			int socketPort = 60000;
			ServerSocket serverSocket = new ServerSocket(socketPort);
			System.out.println("SOCKET_NUMBER : " + socketPort + " IS CONNECTED");

			while (true) {
				Socket socketUser = serverSocket.accept();
				System.out.println("NEW SOCKET GENERATED");
				Thread thd = new MySocketServer(socketUser);
				thd.start(); // Thread 시작
			}

		} catch (IOException e) {
			e.printStackTrace(); // 예외처리
		}

	}

}