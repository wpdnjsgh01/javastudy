package Multitest;

import java.io.*;
import java.net.Socket;

public class ToClientThread extends Thread { // 서버에서 보낸 메세지 읽는 Thread
	
	Socket socket = null;

	public ToClientThread(Socket socket) { // 생성자
		this.socket = socket; // 받아온 Socket Parameter를 해당 클래스 Socket에 넣기
	}

	public void run() {
		try {
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));

			while (true) { // 무한반복
				System.out.println(reader.readLine());
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (socket != null && socket.isClosed() == false) {
					socket.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}